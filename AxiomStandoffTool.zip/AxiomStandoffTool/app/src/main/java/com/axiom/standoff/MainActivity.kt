package com.axiom.standoff

import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val backgroundColor = Color.rgb(13, 14, 19)
    private val surfaceColor = Color.rgb(27, 29, 38)
    private val accentColor = Color.rgb(255, 45, 55)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(26), dp(30), dp(26), dp(30))
            setBackgroundColor(backgroundColor)
        }

        val brand = TextView(this).apply {
            text = "AXIOM"
            textSize = 34f
            setTextColor(accentColor)
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "STANDOFF 2 COMPANION"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }

        val status = TextView(this).apply {
            text = "DURUM: HAZIR"
            textSize = 12f
            setTextColor(Color.rgb(130, 220, 155))
            gravity = Gravity.CENTER
        }

        val espSwitch = createSwitch("ESP GÖRSEL DEMO")
        val aimSwitch = createSwitch("AUTO HEADSHOT DEMO")

        val info = TextView(this).apply {
            text = "Demo anahtarları yalnızca bu uygulamadaki arayüz durumunu değiştirir.\nOyuna müdahale veya hile enjeksiyonu yapmaz."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(14), dp(8), dp(14))
        }

        val startButton = Button(this).apply {
            text = "BAŞLAT"
            textSize = 18f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(accentColor, 18)
            setOnClickListener {
                val gameIntent = packageManager.getLaunchIntentForPackage(
                    "com.axlebolt.standoff2"
                )
                if (gameIntent != null) {
                    startActivity(gameIntent)
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Standoff 2 cihazda bulunamadı.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = rounded(surfaceColor, 18)
        }

        panel.addView(espSwitch)
        panel.addView(divider())
        panel.addView(aimSwitch)

        root.addView(brand)
        root.addView(subtitle)
        root.addView(status, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(space(26))
        root.addView(panel, LinearLayout.LayoutParams(-1, -2))
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        root.addView(space(18))
        root.addView(startButton, LinearLayout.LayoutParams(-1, dp(60)))

        setContentView(root)
    }

    private fun createSwitch(label: String): Switch =
        Switch(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            isChecked = false
            setPadding(0, dp(8), 0, dp(8))
            // These switches are local UI demos only.
        }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Color.rgb(55, 57, 66))
        layoutParams = LinearLayout.LayoutParams(-1, dp(1))
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radiusDp: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}

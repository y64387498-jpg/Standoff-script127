# Axiom Standoff Tool

A minimal Android Studio project for a dark red Standoff 2 companion-style launcher UI.

## Features
- Single **BAŞLAT** button that attempts to open the installed Standoff 2 app.
- ESP and Auto Headshot demo switches. They only change local UI state and do not interact with the game.
- Kotlin Android application; no external dependencies.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The Standoff 2 package name is set to `com.axlebolt.standoff2`. If the installed game uses a different package ID in your region/build, update the string in `MainActivity.kt`.

This project does not inject code into the game, modify game memory, or provide gameplay cheats.
